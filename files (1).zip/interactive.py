#!/usr/bin/env python3
"""Interactive dashboard with matplotlib.widgets.

Controls (left panel): region + channel radio buttons, month range slider, reset.
The charts redraw ~0.3s after you stop moving a control (debounced).

python interactive.py
python interactive.py --snapshot view.png --region South --months 10 12   # headless test
"""
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.widgets import Button, RadioButtons, RangeSlider

from core import AMBER, BG, CARD, CYAN, MONTHS, MUTED, TEXT, draw_dashboard, load

REGIONS = ["All", "North", "South", "East", "West"]
CHANNELS = ["All", "Store", "Online", "App"]
LEFT = .15

here = Path(__file__).parent
ap = argparse.ArgumentParser()
ap.add_argument("--csv", default=here / "sales.csv")
ap.add_argument("--snapshot", help="save a PNG instead of opening a window")
ap.add_argument("--region", default="All", choices=REGIONS)
ap.add_argument("--channel", default="All", choices=CHANNELS)
ap.add_argument("--months", nargs=2, type=int, default=[1, 12])
a = ap.parse_args()

df = load(a.csv)
state = dict(region="All", channel="All", months=(1, 12))
fig = plt.figure(figsize=(23, 14.5), facecolor=BG)
drawn = []


def refresh(*_):
    for ax in drawn:
        ax.remove()
    drawn[:] = draw_dashboard(fig, df, **state, left=LEFT)
    fig.canvas.draw_idle()


# debounce: wait until the user stops dragging before the (heavier) redraw
timer = fig.canvas.new_timer(interval=300)
timer.single_shot = True
timer.add_callback(refresh)


def schedule(*_):
    timer.stop(); timer.start()


# ---- control panel ---------------------------------------------------------------
bg = fig.add_axes([.006, .06, .128, .90], facecolor=CARD)
bg.set_xticks([]); bg.set_yticks([])
for s in bg.spines.values():
    s.set_visible(False)
fig.text(.016, .93, "FILTERS", fontsize=13, fontweight="bold", color=CYAN)


def radio(rect, title, labels, cb):
    fig.text(rect[0] + .004, rect[1] + rect[3] + .012, title, fontsize=9, color=MUTED, fontweight="bold")
    ax = fig.add_axes(rect, facecolor=CARD)
    for s in ax.spines.values():
        s.set_visible(False)
    r = RadioButtons(ax, labels, activecolor=AMBER)
    for lab in r.labels:
        lab.set_color(TEXT); lab.set_fontsize(11)
    r.on_clicked(cb)
    return r


def on_region(v): state["region"] = v; schedule()
def on_channel(v): state["channel"] = v; schedule()


r_reg = radio([.014, .70, .11, .17], "REGION", REGIONS, on_region)
r_chn = radio([.014, .50, .11, .14], "CHANNEL", CHANNELS, on_channel)

fig.text(.016, .435, "MONTHS", fontsize=9, color=MUTED, fontweight="bold")
month_lbl = fig.text(.016, .405, "Jan \u2013 Dec", fontsize=12, color=TEXT)
ax_sl = fig.add_axes([.026, .36, .09, .025], facecolor=CARD)
sl = RangeSlider(ax_sl, "", 1, 12, valinit=(1, 12), valstep=1, color=CYAN)
sl.valtext.set_visible(False)


def on_months(val):
    lo, hi = int(round(val[0])), int(round(val[1]))
    state["months"] = (lo, hi)
    month_lbl.set_text(f"{MONTHS[lo - 1]} \u2013 {MONTHS[hi - 1]}")
    schedule()


sl.on_changed(on_months)

ax_btn = fig.add_axes([.02, .28, .1, .04])
btn = Button(ax_btn, "Reset filters", color="#1F2A3D", hovercolor="#2B3A55")
btn.label.set_color(TEXT)


def on_reset(_):
    r_reg.set_active(0); r_chn.set_active(0); sl.set_val((1, 12))


btn.on_clicked(on_reset)
fig.text(.016, .20, "Drag the slider ends to\nchoose a month range.\nCharts redraw when\nyou let go.",
         fontsize=8.5, color=MUTED, va="top")

# ---- go ----------------------------------------------------------------------------
if a.snapshot:                                   # headless: apply requested state, save, quit
    r_reg.set_active(REGIONS.index(a.region)); r_chn.set_active(CHANNELS.index(a.channel))
    sl.set_val(tuple(a.months))
    refresh()
    fig.savefig(a.snapshot, dpi=90, facecolor=BG)
    print(f"Saved -> {a.snapshot}")
else:
    refresh()
    plt.show()
