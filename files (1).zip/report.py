#!/usr/bin/env python3
"""Multi-page PDF report with matplotlib's PdfPages -> retail_report.pdf

Page 1  Cover + executive summary (KPIs, insights, forecast, scoreboards)
Page 2  Full company dashboard
Pages 3-6  One full dashboard per region
Page 7  Appendix: monthly table (with forecast row) + top-10 products
"""
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.gridspec import GridSpec
from matplotlib.patches import FancyBboxPatch

from core import (AMBER, BG, CARD, CYAN, MONTHS, MUTED, TEXT, analyze, draw_dashboard, draw_forecast,
                  draw_header, draw_table, load, money, panel, pct)

REGIONS = ["East", "North", "South", "West"]


def scoreboard(A, col):
    rows = []
    sel, psel = A["sel"], A["psel"]
    for name, g in sorted(sel.groupby(col), key=lambda kv: -kv[1].revenue.sum()):
        r, p = g.revenue.sum(), g.profit.sum()
        pr = psel[psel[col] == name].revenue.sum() if A["prev"] else 0
        yoy = f"{pct(r, pr):+.0f}%" if pr else "\u2013"
        rows.append([name, money(r), yoy, f"{p / r * 100:.1f}%", f"{len(g):,}"])
    return rows


def cover(df):
    A = analyze(df)
    fig = plt.figure(figsize=(20, 11.25), facecolor=BG)
    gs = GridSpec(3, 6, figure=fig, height_ratios=[.8, 2.5, 2.0], hspace=.5, wspace=.5,
                  left=.04, right=.97, top=.95, bottom=.04)
    draw_header(fig, gs[0, :].subgridspec(1, 7, wspace=.14), A)

    ax = fig.add_subplot(gs[1, :3]); ax.axis("off")
    ax.add_patch(FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0,rounding_size=0.03",
                                transform=ax.transAxes, fc=CARD, ec="none"))
    ax.text(.03, .94, "EXECUTIVE SUMMARY", transform=ax.transAxes, fontsize=12, color=CYAN,
            fontweight="bold", va="top")
    for i, (head, body) in enumerate(A["insights"]):
        y = .84 - i * .105
        ax.text(.03, y, head, transform=ax.transAxes, fontsize=9, color=AMBER, fontweight="bold", va="top")
        ax.text(.03, y - .035, body, transform=ax.transAxes, fontsize=11, color=TEXT, va="top")

    draw_forecast(fig.add_subplot(gs[1, 3:]), A)
    hdr = ["", "Revenue", "YoY", "Margin", "Orders"]
    draw_table(fig.add_subplot(gs[2, :3]), "Region Scoreboard", ["Region"] + hdr[1:], scoreboard(A, "region"), color_col=2)
    draw_table(fig.add_subplot(gs[2, 3:]), "Category Scoreboard", ["Category"] + hdr[1:], scoreboard(A, "category"), color_col=2)
    return fig


def appendix(df):
    A = analyze(df)
    base, cur, prev, fc = A["base"], A["cur"], A["prev"], A["fc"]
    c = base[base.year == cur].groupby("month").agg(rev=("revenue", "sum"), prof=("profit", "sum"), n=("order_id", "count"))
    p = base[base.year == prev].groupby("month").revenue.sum() if prev else None
    rows = []
    for m in range(1, 13):
        pr = p[m] if prev else 0
        rows.append([MONTHS[m - 1], money(pr) if prev else "\u2013", money(c.rev[m]),
                     f"{pct(c.rev[m], pr):+.0f}%" if pr else "\u2013", f"{c.n[m]:,}", f"{c.prof[m] / c.rev[m] * 100:.1f}%"])
    if fc:
        rows.append([f"{fc['next'].strftime('%b %y')} (forecast)", "\u2013", money(fc["fc"]), "\u2013", "\u2013", "\u2013"])

    prod = A["sel"].groupby(["product", "category"]).agg(rev=("revenue", "sum"), prof=("profit", "sum"),
                                                          units=("quantity", "sum")).reset_index().nlargest(10, "prof")
    prow = [[r["product"], r.category, money(r.rev), f"{r.units:,}", f"{r.prof / r.rev * 100:.0f}%"] for _, r in prod.iterrows()]

    fig = plt.figure(figsize=(20, 11.25), facecolor=BG)
    fig.text(.04, .95, "APPENDIX \u2022 DATA TABLES", fontsize=22, fontweight="bold", color=TEXT, va="center")
    gs = GridSpec(1, 6, figure=fig, left=.04, right=.97, top=.86, bottom=.06, wspace=.4)
    draw_table(fig.add_subplot(gs[0, :3]), f"Monthly Performance {cur}",
               ["Month", str(prev) if prev else "Prior", str(cur), "YoY", "Orders", "Margin"], rows, color_col=3)
    draw_table(fig.add_subplot(gs[0, 3:]), "Top 10 Products by Profit",
               ["Product", "Category", "Revenue", "Units", "Margin"], prow)
    return fig


if __name__ == "__main__":
    here = Path(__file__).parent
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default=here / "sales.csv")
    ap.add_argument("--out", default=here / "retail_report.pdf")
    a = ap.parse_args()
    df = load(a.csv)

    with PdfPages(a.out) as pdf:
        def add(fig):
            pdf.savefig(fig, facecolor=BG); plt.close(fig)

        add(cover(df))
        fig = plt.figure(figsize=(22, 19), facecolor=BG); draw_dashboard(fig, df); add(fig)
        for r in REGIONS:
            fig = plt.figure(figsize=(22, 19), facecolor=BG); draw_dashboard(fig, df, region=r); add(fig)
            print(f"  region page: {r}")
        add(appendix(df))
        info = pdf.infodict()
        info["Title"] = "Retail Sales Report"
        info["Author"] = "Retail Command Center"
        info["Subject"] = "Sales performance, YoY comparison and forecast"
    print(f"Saved -> {a.out}")
