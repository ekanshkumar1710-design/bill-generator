"""Shared analysis + drawing code for the Retail Command Center.

dashboard.py (static PNG), interactive.py (widgets) and report.py (PDF)
all call the same functions, so every view stays consistent.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.gridspec import GridSpec
from matplotlib.patches import FancyBboxPatch, Patch
from matplotlib.ticker import FuncFormatter

CUR = "\u20b9"  # change to "$" etc.
BG, CARD, TEXT, MUTED, SLATE = "#0B0F17", "#141A26", "#E6EDF3", "#8B98AD", "#3A4660"
CYAN, PINK, AMBER, GREEN, VIOLET = "#22D3EE", "#F472B6", "#FBBF24", "#34D399", "#A78BFA"
CAT_COL = {"Electronics": CYAN, "Fashion": PINK, "Home": AMBER, "Beauty": VIOLET, "Grocery": GREEN}
REG_COL = {"South": CYAN, "North": AMBER, "West": PINK, "East": VIOLET}
CH_COL = {"Store": GREEN, "Online": "#60A5FA", "App": "#FB7185"}
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

plt.rcParams.update({"font.family": "DejaVu Sans", "text.color": TEXT, "axes.labelcolor": MUTED,
                     "xtick.color": MUTED, "ytick.color": MUTED, "pdf.fonttype": 42})


# ============================================================================ helpers
def money(x):
    """Compact Indian-style money: K / L (lakh) / Cr (crore)."""
    a = abs(x)
    if a >= 1e7: return f"{CUR}{x / 1e7:.2f}Cr"
    if a >= 1e5: return f"{CUR}{x / 1e5:.1f}L"
    if a >= 1e3: return f"{CUR}{x / 1e3:.0f}K"
    return f"{CUR}{x:.0f}"


MONEY_FMT = FuncFormatter(lambda v, _: money(v))
PCT_FMT = FuncFormatter(lambda v, _: f"{v:.0f}%")


def pct(a, b):
    return (a / b - 1) * 100 if b else np.nan


def panel(ax, title, sub=None):
    ax.set_facecolor(CARD)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.tick_params(length=0, labelsize=9)
    ax.set_title(title, loc="left", fontsize=12.5, fontweight="bold", color=TEXT, pad=22 if sub else 10)
    if sub:
        ax.text(0, 1.03, sub, transform=ax.transAxes, fontsize=9, color=MUTED, va="bottom")


def kpi(ax, label, value, note, color, note_color=None):
    ax.axis("off")
    ax.add_patch(FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0,rounding_size=0.08",
                                transform=ax.transAxes, fc=CARD, ec=color, lw=1.4))
    ax.text(.08, .76, label.upper(), transform=ax.transAxes, fontsize=9, color=MUTED, fontweight="bold")
    ax.text(.08, .38, value, transform=ax.transAxes, fontsize=21, color=TEXT, fontweight="bold")
    ax.text(.08, .12, note, transform=ax.transAxes, fontsize=9, color=note_color or color)


def sign_color(v):
    return MUTED if np.isnan(v) else (GREEN if v >= 0 else PINK)


def draw_table(ax, title, header, rows, color_col=None):
    ax.axis("off")
    ax.set_title(title, loc="left", fontsize=12.5, fontweight="bold", color=TEXT, pad=10)
    t = ax.table(cellText=rows, colLabels=header, loc="upper center", cellLoc="center")
    t.auto_set_font_size(False); t.set_fontsize(10); t.scale(1, 1.75)
    for (r, c), cell in t.get_celld().items():
        cell.set_edgecolor(BG); cell.set_linewidth(1.5)
        if r == 0:
            cell.set_facecolor("#1F2A3D"); cell.set_text_props(color=CYAN, fontweight="bold")
        else:
            cell.set_facecolor(CARD if r % 2 else "#10151F"); cell.set_text_props(color=TEXT)
            if c == color_col:
                s = cell.get_text().get_text()
                cell.set_text_props(color=GREEN if s.startswith("+") else PINK if s.startswith("-") else MUTED)


# ============================================================================ data
def load(path):
    df = pd.read_csv(path, parse_dates=["date"])
    df["year"], df["month"], df["dow"] = df.date.dt.year, df.date.dt.month, df.date.dt.dayofweek
    return df


def monthly_series(base):
    s = base.groupby(base.date.dt.to_period("M")).revenue.sum()
    return s.reindex(pd.period_range(s.index.min(), s.index.max(), freq="M"), fill_value=0)


def forecast(s, k=3):
    """Next-month revenue = k-month rolling average x seasonal index.

    seasonal index = (same month last year) / (rolling average that preceded it last year).
    A plain rolling average is also computed so the backtest can show why the index helps.
    """
    v, n = s.values.astype(float), len(s)
    if n < 12 + k + 1:
        return None
    rows = []
    for t in range(12 + k, n):                      # walk-forward backtest
        ma = v[t - k:t].mean()
        rows.append((t, ma, ma * v[t - 12] / v[t - 12 - k:t - 12].mean(), v[t]))
    bt = pd.DataFrame(rows, columns=["t", "ma", "sma", "actual"])
    ma_next = v[n - k:].mean()
    return dict(bt=bt, series=s, ma_next=ma_next, next=s.index[-1] + 1,
                fc=ma_next * v[n - 12] / v[n - 12 - k:n - 12].mean(),
                rmse=float(np.sqrt(((bt.sma - bt.actual) ** 2).mean())),
                mape_ma=float((abs(bt.ma - bt.actual) / bt.actual).mean() * 100),
                mape_sma=float((abs(bt.sma - bt.actual) / bt.actual).mean() * 100))


def analyze(df, region="All", channel="All", months=(1, 12)):
    base = df
    if region != "All": base = base[base.region == region]
    if channel != "All": base = base[base.channel == channel]
    cur = int(df.year.max())
    prev = cur - 1 if (df.year == cur - 1).any() else None
    m0, m1 = months
    inm = base.month.between(m0, m1)
    sel = base[(base.year == cur) & inm]
    psel = base[(base.year == prev) & inm] if prev else base.iloc[0:0]

    def tot(d):
        r, p, n = d.revenue.sum(), d.profit.sum(), len(d)
        return dict(rev=r, prof=p, margin=p / r * 100 if r else 0, orders=n, aov=r / n if n else 0)

    A = dict(base=base, cur=cur, prev=prev, months=months, sel=sel, psel=psel,
             region=region, channel=channel, k=tot(sel), kp=tot(psel) if prev else None,
             fc=forecast(monthly_series(base)))
    A["insights"] = make_insights(A)
    return A


def make_insights(A):
    sel, psel, k, kp, fc = A["sel"], A["psel"], A["k"], A["kp"], A["fc"]
    out = []
    if kp and kp["rev"]:
        g = (sel.groupby("category").revenue.sum() / psel.groupby("category").revenue.sum() - 1).dropna() * 100
        out.append(("GROWTH", f"Revenue {pct(k['rev'], kp['rev']):+.0f}% vs {A['prev']}; "
                              f"{g.idxmax()} grew fastest ({g.max():+.0f}%), {g.idxmin()} slowest ({g.min():+.0f}%)."))
    else:
        out.append(("GROWTH", "No prior-year data to compare against."))
    mo = sel.groupby("month").revenue.sum(); bm = mo.idxmax()
    out.append(("MOMENTUM", f"{MONTHS[bm - 1]} is the peak month with {mo[bm] / k['rev'] * 100:.0f}% of period revenue."))
    wk = sel.groupby("dow").revenue.sum()
    wkday = sel[sel.dow < 5].groupby("date").revenue.sum().mean()
    wkend = sel[sel.dow >= 5].groupby("date").revenue.sum().mean()
    out.append(("WEEKLY RHYTHM", f"{DAYS[wk.idxmax()]} leads; weekend days earn {pct(wkend, wkday):+.0f}% vs weekdays."))
    hr = sel.groupby("hour").size().reindex(range(24), fill_value=0)
    out.append(("PEAK WINDOW", f"Traffic peaks around {int(hr.rolling(3, center=True).sum().idxmax()):02d}:00 (\u00b11h) - staff and promote around it."))
    ds = sel.groupby("discount_pct").agg(rev=("revenue", "sum"), prof=("profit", "sum"))
    ds["mg"] = ds.prof / ds.rev * 100
    bd, td = ds.prof.idxmax(), ds.index.max()
    out.append(("DISCOUNTS", f"{bd}% discount earns the most profit; at {td}% margin falls to {ds.mg[td]:.0f}%."))
    if fc:
        out.append(("FORECAST", f"{fc['next'].strftime('%b %Y')} revenue forecast: {money(fc['fc'])} (\u00b1{money(fc['rmse'])})."))
    cat = sel.groupby("category").agg(rev=("revenue", "sum"), prof=("profit", "sum"))
    cat["mg"] = cat.prof / cat.rev * 100
    out.append(("CATEGORIES", f"{cat.rev.idxmax()} drives {cat.rev.max() / k['rev'] * 100:.0f}% of sales; {cat.mg.idxmax()} has the best margin ({cat.mg.max():.0f}%)."))
    vip = sel[sel.segment == "VIP"]
    out.append(("LOYALTY", f"VIPs are {len(vip) / len(sel) * 100:.0f}% of orders but {vip.revenue.sum() / k['rev'] * 100:.0f}% of revenue."))
    return out


# ============================================================================ reusable panels
def draw_header(fig, spec, A):
    k, kp, prev = A["k"], A["kp"], A["prev"]
    m0, m1 = A["months"]
    t = fig.add_subplot(spec[0, 0:2]); t.axis("off")
    t.text(0, .74, "RETAIL SALES", fontsize=27, fontweight="bold", color=TEXT, va="center")
    t.text(0, .40, f"COMMAND CENTER  \u2022  FY {A['cur']}", fontsize=14, color=CYAN, fontweight="bold", va="center")
    t.text(0, .10, f"{'All regions' if A['region'] == 'All' else A['region']}  \u2022  "
                   f"{'All channels' if A['channel'] == 'All' else A['channel']}  \u2022  "
                   f"{MONTHS[m0 - 1]}\u2013{MONTHS[m1 - 1]}", fontsize=10.5, color=MUTED, va="center")

    def note(key, fallback, delta=None):
        if not kp:
            return fallback, None
        d = pct(k[key], kp[key]) if delta is None else delta
        return f"{d:+.0f}% vs {prev}", sign_color(d)

    n_rev, c_rev = note("rev", "total sales")
    n_prof, c_prof = note("prof", "after cost of goods")
    mg_d = k["margin"] - kp["margin"] if kp else np.nan
    n_mg, c_mg = (f"{mg_d:+.1f} pts vs {prev}", sign_color(mg_d)) if kp else ("profit / revenue", None)
    n_ord, c_ord = note("orders", f"{k['orders'] / max(sel_days(A), 1):.0f} per day")
    n_aov, c_aov = note("aov", "per order")
    kpi(fig.add_subplot(spec[0, 2]), "Revenue", money(k["rev"]), n_rev, CYAN, c_rev)
    kpi(fig.add_subplot(spec[0, 3]), "Profit", money(k["prof"]), n_prof, GREEN, c_prof)
    kpi(fig.add_subplot(spec[0, 4]), "Margin", f"{k['margin']:.1f}%", n_mg, AMBER, c_mg)
    kpi(fig.add_subplot(spec[0, 5]), "Orders", f"{k['orders']:,}", n_ord, PINK, c_ord)
    kpi(fig.add_subplot(spec[0, 6]), "Avg order", f"{CUR}{k['aov']:,.0f}", n_aov, VIOLET, c_aov)


def sel_days(A):
    return A["sel"].date.nunique()


def draw_forecast(ax, A):
    fc = A["fc"]
    if not fc:
        panel(ax, "Next-Month Forecast", "needs at least 16 months of history")
        return
    panel(ax, "Next-Month Revenue Forecast",
          f"3-month rolling avg \u00d7 seasonal index  \u2022  backtest error {fc['mape_sma']:.0f}% "
          f"(plain rolling avg: {fc['mape_ma']:.0f}%)")
    s, n, bt = fc["series"], len(fc["series"]), fc["bt"]
    periods = list(s.index) + [fc["next"]]
    ax.plot(range(n), s.values, color=CYAN, lw=2.4, marker="o", ms=4, label="Actual")
    ax.plot(bt.t, bt.sma, color=VIOLET, ls="--", lw=1.8, marker="s", ms=4, label="Backtest (seasonal)")
    ax.plot([n - 1, n], [s.values[-1], fc["fc"]], color=AMBER, lw=1.4, ls=":")
    ax.errorbar(n, fc["fc"], yerr=fc["rmse"], fmt="D", color=AMBER, ms=9, capsize=5, lw=2, label="Forecast \u00b1 error")
    ax.scatter([n], [fc["ma_next"]], marker="o", facecolors="none", edgecolors=PINK, s=90, lw=1.8,
               label="Plain rolling avg", zorder=4)
    ax.annotate(f"{fc['next'].strftime('%b %Y')}\n{money(fc['fc'])}", (n, fc["fc"]), xytext=(-78, 22),
                textcoords="offset points", color=AMBER, fontsize=10, fontweight="bold",
                arrowprops=dict(arrowstyle="-", color=AMBER))
    ax.set_xticks(range(0, n + 1, 3), [periods[i].strftime("%b\n%y") for i in range(0, n + 1, 3)])
    ax.set_xlim(-.7, n + 1); ax.set_ylim(0, max(s.max(), fc["fc"] + fc["rmse"]) * 1.2)
    ax.yaxis.set_major_formatter(MONEY_FMT)
    ax.legend(loc="upper left", ncol=2, fontsize=8, frameon=False, labelcolor=MUTED)


# ============================================================================ the dashboard
def draw_dashboard(fig, df, region="All", channel="All", months=(1, 12), left=.065):
    """Draw the full dashboard onto `fig`; returns the new axes (so callers can redraw)."""
    A = analyze(df, region, channel, months)
    before = set(fig.axes)
    sel, psel, base, cur, prev = A["sel"], A["psel"], A["base"], A["cur"], A["prev"]
    k, fc = A["k"], A["fc"]
    m0, m1 = months

    gs = GridSpec(6, 6, figure=fig, height_ratios=[.85, 1.9, 2.0, 2.1, 2.2, 1.35],
                  hspace=.66, wspace=.55, left=left, right=.975, top=.965, bottom=.02)
    draw_header(fig, gs[0, :].subgridspec(1, 7, wspace=.14), A)

    # --- calendar heatmap --------------------------------------------------------
    daily = sel.groupby("date").revenue.sum().reindex(pd.date_range(f"{cur}-01-01", f"{cur}-12-31"))
    offset = daily.index[0].dayofweek
    grid = np.full((7, 54), np.nan)
    for d, v in daily.items():
        grid[d.dayofweek, (d.dayofyear - 1 + offset) // 7] = v
    ax = fig.add_subplot(gs[1, :4])
    panel(ax, "Daily Revenue Calendar",
          f"Each square is a day  \u2022  peak: {daily.idxmax():%d %b} ({money(daily.max())})")
    cal = LinearSegmentedColormap.from_list("cal", ["#1B2538", "#0E5A78", CYAN, AMBER, PINK])
    m = ax.pcolormesh(np.ma.masked_invalid(grid), cmap=cal, edgecolors=CARD, linewidth=2.2)
    ax.invert_yaxis()
    ax.set_yticks(np.arange(7) + .5, DAYS)
    ax.set_xticks([(pd.Timestamp(f"{cur}-{mo:02d}-01").dayofyear - 1 + offset) // 7 + .5 for mo in range(1, 13)], MONTHS)
    cb = fig.colorbar(m, ax=ax, orientation="horizontal", fraction=.07, pad=.14, aspect=60)
    cb.ax.xaxis.set_major_formatter(MONEY_FMT); cb.outline.set_visible(False)
    cb.ax.tick_params(labelsize=8, length=0)

    # --- double donut --------------------------------------------------------------
    ax = fig.add_subplot(gs[1, 4:]); ax.set_facecolor(CARD)
    ax.set_title("Revenue Mix", loc="left", fontsize=12.5, fontweight="bold", pad=10)
    reg = sel.groupby("region").revenue.sum().sort_values(ascending=False)
    chn = sel.groupby("channel").revenue.sum().sort_values(ascending=False)
    wd = dict(width=.3, edgecolor=CARD, linewidth=2)
    ax.pie(reg, radius=1, colors=[REG_COL[i] for i in reg.index], startangle=90, counterclock=False,
           wedgeprops=wd, autopct="%1.0f%%", pctdistance=.85,
           textprops=dict(color=BG, fontsize=9, fontweight="bold"))
    ax.pie(chn, radius=.68, colors=[CH_COL[i] for i in chn.index], startangle=90, counterclock=False,
           wedgeprops=wd, autopct="%1.0f%%", pctdistance=.78,
           textprops=dict(color=BG, fontsize=8, fontweight="bold"))
    handles = [plt.Line2D([], [], marker="o", ls="", color=c, label=l) for l, c in
               [(i, REG_COL[i]) for i in reg.index] + [(i, CH_COL[i]) for i in chn.index]]
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(.5, .02), ncol=4, frameon=False,
              fontsize=8, labelcolor=MUTED, handletextpad=.2, columnspacing=.8)

    # --- year-over-year monthly bars -----------------------------------------------
    cm = base[base.year == cur].groupby("month").revenue.sum().reindex(range(1, 13), fill_value=0)
    pm = base[base.year == prev].groupby("month").revenue.sum().reindex(range(1, 13), fill_value=0) if prev else None
    ax = fig.add_subplot(gs[2, :3])
    panel(ax, f"Year-over-Year Revenue: {prev} vs {cur}" if prev else "Monthly Revenue",
          "labels show growth vs same month last year" if prev else None)
    x = np.arange(1, 13)
    inrange = (x >= m0) & (x <= m1)
    best_m = int(x[inrange][np.argmax(cm.values[inrange])])
    w = .38 if prev else .68
    if prev:
        ax.bar(x - .2, pm.values, w, color=SLATE, alpha=.95)
    ax.bar(x + (.2 if prev else 0), cm.values, w,
           color=[AMBER if i == best_m else CYAN for i in x], alpha=.92)
    if prev:
        for i in x:
            if pm[i] > 0 and cm[i] > 0:
                g = pct(cm[i], pm[i])
                ax.text(i, max(cm[i], pm[i]) * 1.02, f"{g:+.0f}%", ha="center", fontsize=7.5,
                        color=sign_color(g), fontweight="bold")
        ax.legend(handles=[Patch(color=SLATE, label=str(prev)), Patch(color=CYAN, label=str(cur))],
                  loc="lower right", bbox_to_anchor=(1, 1.01), ncol=2, frameon=False, fontsize=9, labelcolor=MUTED)
    if (m0, m1) != (1, 12):
        ax.axvspan(m0 - .5, m1 + .5, color="white", alpha=.06, zorder=0)
    ax.set_xticks(x, MONTHS); ax.yaxis.set_major_formatter(MONEY_FMT)
    ax.set_ylim(0, max(cm.max(), pm.max() if prev else 0) * 1.16)

    # --- weekday x hour heatmap ----------------------------------------------------
    hm = sel.pivot_table(index="dow", columns="hour", values="order_id", aggfunc="count", fill_value=0)
    hm = hm.reindex(index=range(7), columns=range(24), fill_value=0)
    ax = fig.add_subplot(gs[2, 3:])
    panel(ax, "When Do Customers Buy?", "orders by weekday and hour")
    heat = LinearSegmentedColormap.from_list("heat", [CARD, "#3B1D6B", "#C026D3", AMBER, "#FFF3C4"])
    ax.pcolormesh(hm.values, cmap=heat, edgecolors=CARD, linewidth=1.5)
    ax.invert_yaxis()
    ax.set_yticks(np.arange(7) + .5, DAYS)
    ax.set_xticks(np.arange(0, 24, 3) + .5, [f"{h:02d}:00" for h in range(0, 24, 3)])

    # --- forecast ----------------------------------------------------------------------
    draw_forecast(fig.add_subplot(gs[3, :3]), A)

    # --- growth by category ----------------------------------------------------------------
    ax = fig.add_subplot(gs[3, 3:])
    c = sel.groupby("category").revenue.sum()
    if prev:
        g = ((c / psel.groupby("category").revenue.sum() - 1) * 100).dropna().sort_values()
        panel(ax, f"Category Growth vs {prev}", "same months, revenue growth (revenue in brackets)")
        yy = np.arange(len(g))
        ax.barh(yy, g.values, color=[CAT_COL[i] for i in g.index], height=.55)
        lo, hi = min(g.min(), 0), max(g.max(), 0); pad = (hi - lo) * .3
        for i, (name, v) in enumerate(g.items()):
            ax.text(v + (hi - lo) * .02 * (1 if v >= 0 else -1), i, f"{v:+.0f}%  ({money(c[name])})",
                    va="center", ha="left" if v >= 0 else "right", fontsize=9, color=TEXT)
        ax.axvline(0, color=MUTED, lw=.8)
        ax.set_yticks(yy, g.index); ax.set_xlim(lo - pad, hi + pad); ax.xaxis.set_major_formatter(PCT_FMT)
    else:
        c = c.sort_values()
        panel(ax, "Category Revenue", "no prior year available")
        ax.barh(c.index, c.values, color=[CAT_COL[i] for i in c.index], height=.55)
        ax.xaxis.set_major_formatter(MONEY_FMT)

    # --- top products lollipop ---------------------------------------------------------------
    prod = sel.groupby(["category", "product"]).agg(rev=("revenue", "sum"), prof=("profit", "sum"),
                                                     units=("quantity", "sum")).reset_index()
    prod["mg"] = prod.prof / prod.rev * 100
    top8 = prod.nlargest(8, "prof").iloc[::-1]
    ax = fig.add_subplot(gs[4, :2])
    panel(ax, "Top 8 Products by Profit", "dot colour = category")
    cols = [CAT_COL[i] for i in top8.category]
    ax.hlines(top8["product"], 0, top8.prof, color=cols, lw=3, alpha=.8)
    ax.scatter(top8.prof, top8["product"], color=cols, s=130, zorder=3, edgecolor=CARD, lw=2)
    for v, p in zip(top8.prof, top8["product"]):
        ax.text(v + top8.prof.max() * .03, p, money(v), va="center", fontsize=9, color=TEXT)
    ax.set_xlim(0, top8.prof.max() * 1.22); ax.xaxis.set_major_formatter(MONEY_FMT)
    ax.grid(axis="x", color=BG, lw=1); ax.set_axisbelow(True)

    # --- discount sweet spot -----------------------------------------------------------------
    ds = sel.groupby("discount_pct").agg(rev=("revenue", "sum"), prof=("profit", "sum"))
    ds["mg"] = ds.prof / ds.rev * 100
    best_d = ds.prof.idxmax()
    ax = fig.add_subplot(gs[4, 2:4])
    panel(ax, "Discount Sweet Spot", "bars = total profit  \u2022  line = margin %")
    xs = np.arange(len(ds))
    ax.bar(xs, ds.prof, color=[AMBER if d == best_d else VIOLET for d in ds.index], width=.62, alpha=.92)
    ax.set_xticks(xs, [f"{d}%" for d in ds.index]); ax.yaxis.set_major_formatter(MONEY_FMT)
    ax.set_xlabel("discount given", fontsize=9)
    a2 = ax.twinx(); a2.plot(xs, ds.mg, color=PINK, lw=2.4, marker="o", ms=6)
    a2.set_ylim(min(0, ds.mg.min() - 3), ds.mg.max() + 8); a2.yaxis.set_major_formatter(PCT_FMT)
    a2.tick_params(length=0, labelsize=9)
    for s in a2.spines.values(): s.set_visible(False)

    # --- portfolio bubble ----------------------------------------------------------------------
    ax = fig.add_subplot(gs[4, 4:])
    panel(ax, "Product Portfolio Map", "x = revenue  \u2022  y = margin  \u2022  bubble = units sold")
    ax.scatter(prod.rev, prod.mg, s=prod.units / prod.units.max() * 900 + 50,
               c=[CAT_COL[i] for i in prod.category], alpha=.85, edgecolor=CARD, lw=1.5)
    for _, r in prod.iterrows():
        ax.annotate(r["product"], (r.rev, r.mg), xytext=(7, 7), textcoords="offset points", fontsize=7, color=MUTED)
    ax.axvline(prod.rev.median(), color=MUTED, ls="--", lw=.8, alpha=.6)
    ax.axhline(prod.mg.median(), color=MUTED, ls="--", lw=.8, alpha=.6)
    for txt, (xx, yy_), col, ha, va in [("STARS", (.98, .96), GREEN, "right", "top"),
                                        ("NICHE GEMS", (.02, .96), CYAN, "left", "top"),
                                        ("VOLUME DRIVERS", (.98, .03), AMBER, "right", "bottom"),
                                        ("REVIEW", (.02, .03), PINK, "left", "bottom")]:
        ax.text(xx, yy_, txt, transform=ax.transAxes, ha=ha, va=va, color=col, fontsize=9, fontweight="bold")
    ax.xaxis.set_major_formatter(MONEY_FMT); ax.yaxis.set_major_formatter(PCT_FMT); ax.margins(.12)

    # --- auto insights ----------------------------------------------------------------------------
    ax = fig.add_subplot(gs[5, :]); ax.axis("off")
    ax.add_patch(FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0,rounding_size=0.04",
                                transform=ax.transAxes, fc=CARD, ec="none"))
    ax.text(.015, .86, "AUTO-GENERATED INSIGHTS", transform=ax.transAxes, fontsize=10, color=CYAN,
            fontweight="bold", va="top")
    for i, (head, body) in enumerate(A["insights"][:6]):
        xx, yy_ = .015 + (i % 3) * .328, .66 - (i // 3) * .36
        ax.text(xx, yy_, head, transform=ax.transAxes, fontsize=8.5, color=AMBER, fontweight="bold", va="top")
        ax.text(xx, yy_ - .13, body, transform=ax.transAxes, fontsize=10, color=TEXT, va="top")

    return [a for a in fig.axes if a not in before]
